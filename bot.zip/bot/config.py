TOKEN = '5512424007:AAGeAjpTZSlQN-TMYMWoGly9AvtiS9M9fDo'
keys = {
    'биткоин': 'BTC',
    'эфириум': 'ETH',
    'доллар': 'USD',
}